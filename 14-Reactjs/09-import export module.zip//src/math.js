const pi = 3.1421;

function doublePi() {
  return 2 * pi;
}
function triplePi() {
  return 3 * pi;
}

export default pi;
export { doublePi, triplePi };
